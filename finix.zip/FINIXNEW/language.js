global.spesialprem = 'Only premium on database'
global.spesialown = 'Only owner on database'
global.notext = '!send text!'
global.noingroup = 'Only group feature'
global.nobotadmin = 'Only bot admin feature'
global.usernoadmin = 'Only admin feature'
global.gabisafix = "Sorry, your number is not in the database"